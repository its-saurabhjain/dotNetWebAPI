using System.Web.Http;

namespace SocialNetwork.Api.Controllers
{
    public abstract class SocialNetworkApiController : ApiController
    {
    }
}